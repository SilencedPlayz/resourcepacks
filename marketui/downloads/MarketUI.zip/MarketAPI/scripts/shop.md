Ores - Coal
* Coal - 4.0
* Iron ingot - 12.88
* Copper inggot - 2.55
* Gold ingot - 77.50
* redstone dust - 32.28
* lapis lazuli - 27.36
* emerald - 20.0
* diamond - 285.30
* amethyst shard - 40.0

Mining - Iron pic
* cobblestone - 16.0

Mob drops - bone

food - raw beef

wood logs - iron axe

crops - wheat

spawners - mob spawner