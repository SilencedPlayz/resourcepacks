import {world,system,ItemStack} from "@minecraft/server";
import {ActionFormData,ModalFormData,MessageFormData} from "@minecraft/server-ui"
import {MarketForm} from "./marketform.js"

function send(player){
  player.sendMessage("Works")
}

const shop = new MarketForm(
[
  {
    name: "General",
    icon: "textures/items/emerald",
    items: [
      {icon: "textures/items/emerald", price: 10, func: (target)=>send(target)},
      {icon: "textures/items/diamond", price: 20, func: (target)=>send(target)},
      {icon: "textures/items/gold_ingot", price: 15, func: (target)=>send(target)},
      {icon: "textures/items/iron_ingot", price: 5, func: (target)=>send(target)},
      {icon: "textures/items/coal", price: 2, func: (target)=>send(target)},
      {icon: "textures/blocks/stone", price: 1, func: (target)=>send(target)},
      {icon: "textures/blocks/dirt", price: 1, func: (target)=>send(target)},
    ]
  },
  {
    name: "Farming",
    icon: "textures/items/wheat",
    items: [
      {icon: "textures/items/wheat_seeds", price: 5, func: (target)=>send(target)},
      {icon: "textures/items/carrot", price: 3, func: (target)=>send(target)},
      {icon: "textures/items/potato", price: 3, func: (target)=>send(target)},
      {icon: "textures/items/apple", price: 2, func: (target)=>send(target)},
      {icon: "textures/items/melon", price: 5, func: (target)=>send(target)},
    ]
  },
  {
    name: "Weapons",
    icon: "textures/items/iron_sword",
    items: [
      {icon: "textures/items/wooden_sword", price: 10, func: (target)=>send(target)},
      {icon: "textures/items/stone_sword", price: 20, func: (target)=>send(target)},
      {icon: "textures/items/iron_sword", price: 30, func: (target)=>send(target)},
      {icon: "textures/items/diamond_sword", price: 50, func: (target)=>send(target)},
    ]
  },
  {
    name: "Armor",
    icon: "textures/items/leather_helmet",
    items: [
      {icon: "textures/items/leather_helmet", price: 10, func: (target)=>send(target)},
      {icon: "textures/items/leather_chestplate", price: 20, func: (target)=>send(target)},
      {icon: "textures/items/leather_leggings", price: 15, func: (target)=>send(target)},
      {icon: "textures/items/leather_boots", price: 10, func: (target)=>send(target)},
    ]
  },
  {
    name: "Tools",
    icon: "textures/items/stone_pickaxe",
    items: [
      {icon: "textures/items/stone_pickaxe", price: 10, func: (target)=>send(target)},
      {icon: "textures/items/iron_pickaxe", price: 20, func: (target)=>send(target)},
      {icon: "textures/items/diamond_pickaxe", price: 30, func: (target)=>send(target)},
    ]
  },
  {
    name: "Blocks",
    icon: "textures/blocks/stone",
    items: [
      {icon: "textures/blocks/stone", price: 1, func: (target)=>send(target)},
      {icon: "textures/blocks/dirt", price: 1, func: (target)=>send(target)},
      {icon: "textures/blocks/grass_side", price: 2, func: (target)=>send(target)},
    ]
  },
  {
    name: "Misc",
    icon: "textures/items/ender_pearl",
    items: [
      {icon: "textures/items/ender_pearl", price: 50, func: (target)=>send(target)},
      {icon: "textures/items/eye_of_ender", price: 20, func: (target)=>send(target)},
    ]
  }
])

world.afterEvents.itemUse.subscribe(data => {
  const {itemStack: item, source: player} = data;
  
  if(item.typeId === "minecraft:stick"){
    if(player.isSneaking){
      shop.show(player, 0)
    }else{
      shop.show(player, 1)
    }
  }
  if(item.typeId === "minecraft:emerald"){
    if(player.isSneaking){
      shop.show(player, 0)
    }else{
      shop.show(player, 1)
    }
  }
})